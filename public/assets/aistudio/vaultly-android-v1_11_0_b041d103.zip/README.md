# Vaultly

**A private, offline vault for your cards, bank accounts, IDs and important documents. Android. No account, no cloud, no tracking.**

![Platform: Android](https://img.shields.io/badge/platform-Android-3ddc84)
![Version](https://img.shields.io/badge/version-1.11.0-blue)
![License: MIT](https://img.shields.io/badge/license-MIT-green)
![Network: offline](https://img.shields.io/badge/network-offline-informational)

> Vaultly keeps everything encrypted on your phone with a master password. It declares no internet permission, so it cannot send your data anywhere.

<!-- Add screenshots here (use sample data only):
![Home](docs/screenshots/home.png) ![Card](docs/screenshots/card.png) ![Insights](docs/screenshots/insights.png) -->

---

## Contents
- [Features](#features)
- [Security model](#security-model)
- [Privacy and permissions](#privacy-and-permissions)
- [Getting started (build from source)](#getting-started-build-from-source)
- [Releasing a signed APK](#releasing-a-signed-apk)
- [Backups and restoring](#backups-and-restoring)
- [Project structure](#project-structure)
- [Roadmap](#roadmap)
- [FAQ](#faq)
- [Disclaimer](#disclaimer)
- [Contributing, security reports and licence](#contributing-security-reports-and-licence)

---

## Features

### Store
- **Cards** with bank, name, network, variant (for example Visa Signature), holder, number, expiry, CVV, credit or debit, add-on cards, limit, favourites, custom colours, patterns and your own background picture.
- **Accounts, IDs, secure notes, logins, insurance policies, vehicle documents and bills.** Photos can be attached to anything.
- **Profiles** for family members, each with a photo.
- **Scan** a card with the camera (auto edge detection and crop, then on-device text recognition) or **tap** a contactless card (NFC) to read the number and expiry. The CVV is never on the chip.
- **Authenticator codes:** save a login's two-step key and see its live 6-digit code on the login page.
- **Password generator** for logins (length, symbols, or easy-to-read).
- **Card flip:** tap a card to see its back photo.
- **Long-press a card** for quick actions: quick preview, share, copy number, favourite, lost or stolen, edit, recycle bin.

### Money tools
- **Bills:** record the statement bill, pay it in full or in part, and watch the balance fall. Paying in full switches that month's reminder off.
- **Limit usage** bar from what you owe against the limit.
- **Annual-fee waiver tracker:** progress toward the spend that waives the fee.
- **Lounge access:** free visits per quarter or year, domestic or international, with minimum-spend notes. Counts reset each period.
- **Reminders:** bill due, statement date, annual fee and ID expiry as local notifications that show only the card name.
- **Spend tracking and insights:** optional reader for bank and UPI alert notifications. New alerts are listed for review when you unlock. Monthly insights with categories.
- **New-card detection:** a "card dispatched or approved" alert creates a ready-made card stub (last 4 digits, bank, limit). You can also share an SMS or email to Vaultly.
- **EMI tracker:** record EMIs on a card (monthly amount, months, due day), mark each month paid, see months left and the amount still to pay, with due reminders.
- **Lost or stolen helper:** call your bank, mark the card as blocked (its reminders stop) and follow a short checklist.

### Organise
- Group by bank, network or show all. Sort by name (A to Z or Z to A), expiry, date added or limit.
- **Search everything** from the home screen, or search within a tab.
- Recycle bin keeps deleted items for 30 days with Undo.

### Look and feel
- Light, dark, black, Aurora, Ocean, Sunset and Candy themes, plus accent colours.
- Eight app icons you can switch between.
- On-screen PIN keypad with vibration, slide transitions and a status bar that follows your theme.
- Every optional feature has a switch in Settings.

### Backup and move
- **Encrypted backup** file (includes photos) with share sheet export, so you can store it in Drive, OneDrive or anywhere.
- **Automatic backups** to a folder you choose, on a schedule you choose, keeping the latest N files.
- **Test a backup** file without restoring it.
- **Bitwarden JSON** import (cards) and export.

---

## Security model

| Area | How it works |
| --- | --- |
| Vault encryption | AES-256-GCM. Key derived from the master password with PBKDF2-SHA256, 250,000 iterations and a random 16-byte salt. A fresh random 12-byte IV for every save. |
| Master password | Never stored. The derived key lives in memory only while unlocked and is dropped on lock. |
| Biometric unlock | The master password is encrypted with an AES key held in the Android Keystore. The key needs a strong biometric match for every use and is destroyed by Android if a new fingerprint is added. |
| PIN unlock | The master password is encrypted with a key derived from the PIN and kept in secure storage. Five wrong tries turn the PIN off. |
| Wrong passwords | Repeated failures add a growing wait before the next try. |
| Screen | Screenshots, screen recording and the recent-apps preview are blocked by default (can be allowed). |
| Auto-lock | Immediately, 30 s, 1 min, 5 min or 15 min, and whenever the app goes to the background. |
| Clipboard | Copied numbers are cleared after 45 seconds. |
| Extra lock | Optional: ask for fingerprint, PIN or master password before showing or copying a CVV, card number or password, before showing an authenticator code and before sharing. Confirmation lasts one minute. |
| Backups | Android cloud backup is disabled. Exported backups are the same encrypted vault file. |

**Limits.** A weak master password weakens everything. A rooted or compromised phone is not defended against. Biometric and PIN unlock are conveniences on top of the master password. The app has not had an independent security audit. See [SECURITY.md](SECURITY.md).

## Privacy and permissions

Vaultly has no account, no analytics, no ads and no network access. Full details are in [PRIVACY.md](PRIVACY.md).

| Permission | Why |
| --- | --- |
| Camera | Scan cards and take document photos. |
| NFC | Read a card number and expiry by tapping it. |
| Biometrics | Fingerprint or face unlock. |
| Vibrate | Keypad and button feedback. |
| Notifications | Bill, fee and ID-expiry reminders. |
| Notification access (optional) | Lets the spend reader see bank and UPI alerts. You grant it in system settings and can revoke it any time. |
| A folder you pick (optional) | Where automatic backups are written. |

---

## Getting started (build from source)

**Requirements**
- Node.js 22 or newer
- Android Studio (current stable) with the Android SDK
- JDK 21 (bundled with Android Studio as *jbr-21*)

**Steps (Windows, macOS or Linux)**
```bash
git clone https://github.com/YOURNAME/vaultly.git
cd vaultly
npm install
npx cap sync android
npx cap open android
```
Then press **Run** in Android Studio with a phone connected (USB debugging on) or an emulator. In the Gradle settings choose **jbr-21** as the Gradle JDK.

> On Windows PowerShell, if `npm` is blocked by the execution policy, use Command Prompt or run `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`.

**Editing the app.** The interface is one file, `www/index.html`. The bridge to phone features is `src/native.js`, bundled with `npm run build:web` (needs esbuild) into `www/native.js`. After any change run `npx cap sync android`.

**Using your own app ID.** Change `appId` in `capacitor.config.json`, `applicationId` in `android/app/build.gradle` and `package_name` plus `custom_url_scheme` in `android/app/src/main/res/values/strings.xml`. Leave the Java `namespace` as it is.

## Releasing a signed APK
1. Android Studio: **Build > Generate Signed App Bundle / APK > APK > Create new keystore**.
2. Keep the `.jks` file **outside the repository** and back it up. Losing it means you can never update the app.
3. Raise `versionCode` and `versionName` in `android/app/build.gradle` for every release.
4. Attach the APK to a GitHub **Release** rather than committing it.
5. A debug build and a release build are signed differently, so Android will not update one over the other. Export a backup before switching.

## Backups and restoring
- **Settings > Backup and transfer > Encrypted backup > Export**, then save the file somewhere safe.
- **Settings > Automatic backup** writes encrypted files to a folder on a schedule.
- **Restore:** Settings > Backup and transfer > Import, choose the file and enter the password it was made with.
- **Check a backup:** Settings > Backup and transfer > Test a backup file.
- The password for a backup is the master password at the time it was made. There is no recovery if it is forgotten.

## Project structure
```
vaultly/
  www/                    the app (index.html, native.js bundle, icons, hero artwork)
  src/native.js           bridge to Android features (bundled into www/native.js)
  android/                Android Studio project (Capacitor)
    app/src/main/java/com/mycards/vault/
      MainActivity.java       secure window, share target, plugin registration
      BioVaultPlugin.java     Keystore-bound biometric unlock
      CardNfcPlugin.java      contactless card reader
      NotifService.java       optional alert reader (queues bank and UPI alerts)
      NotifPlugin.java        bridge for the alert reader and shared text
      BackupPlugin.java       automatic backup to a chosen folder
      AppIconPlugin.java      switchable launcher icons
      ScreenPlugin.java       screenshot blocking toggle
  capacitor.config.json
  CHANGELOG.md  PRIVACY.md  SECURITY.md  CONTRIBUTING.md  ROADMAP.md  LICENSE
```

## Roadmap
See [ROADMAP.md](ROADMAP.md). Near term: lounge access auto-fill from a built-in card list, reward points, budgets and charts, search shortcuts.

## FAQ
**Why no cloud sync?** Privacy by design: no network permission means nothing can leak. Use encrypted backups and the folder backup (any synced folder works).

**Can it autofill my card in other apps?** Not yet. See the roadmap.

**What if I forget the master password?** The data cannot be recovered. That is what makes it secure.

**Does it read my SMS?** No. The optional reader uses notification access, not SMS permission, only for alerts that look like bank or UPI messages, and it ignores anything mentioning an OTP.

**Will banks or Google mind?** The app is for personal use. It stores what you type. Do not distribute a build that handles other people's financial data without a proper security review and privacy policy.

## Disclaimer
Vaultly is an independent personal project. It is not affiliated with any bank, card network or payment system. Brand names appear only to describe your own cards. Use at your own risk and keep backups.

## Contributing, security reports and licence
- Contributions: [CONTRIBUTING.md](CONTRIBUTING.md)
- Report a vulnerability privately: [SECURITY.md](SECURITY.md)
- Licence: [MIT](LICENSE)
